using iTextSharp.text;
using iTextSharp.text.pdf;
using Libreria_VR_Peliculas.Entidades;
using Libreria_VR_Peliculas_Presentacion.Implementaciones;
using Libreria_VR_Peliculas_Presentacion.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace APS_VR_Peliculas_Preseentacion.Pages
{
    public class FacturasHTMLModel : PageModel
    {
        private IFacturas_Presentacion? IFacturas;
        private IClientes_Presentacion? IClientes;
        private IRentas_Presentacion? IRentas;
        private IVentas_Presentacion? IVentas;
        private IDescuentos_Presentacion? IDescuentos;
        [BindProperty] public List<Facturas>? Lista { get; set; }
        [BindProperty] public Facturas? Actual { get; set; }
        [BindProperty] public bool Borrando { get; set; }
        public List<Clientes>? ListaClientes { get; set; }
        public List<Rentas>? ListaRentas { get; set; }
        public List<Ventas>? ListaVentas { get; set; }
        public List<Descuentos>? ListaDescuentos { get; set; }

        public FacturasHTMLModel()
        {
            IFacturas = new Facturas_Presentacion();
            IClientes = new Clientes_Presentacion();
            IRentas = new Rentas_Presentacion();
            IVentas = new Ventas_Presentacion();
            IDescuentos = new Descuentos_Presentacion();
        }

        private void CargarListas()
        {
            try { ListaClientes = IClientes!.Consultar(); } catch { ListaClientes = new List<Clientes>(); }
            try { ListaRentas = IRentas!.Consultar(); } catch { ListaRentas = new List<Rentas>(); }
            try { ListaVentas = IVentas!.Consultar(); } catch { ListaVentas = new List<Ventas>(); }
            try { ListaDescuentos = IDescuentos!.Consultar(); } catch { ListaDescuentos = new List<Descuentos>(); }
        }

        public void OnGet()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
            CargarListas();
            OnPostBtRefrescar();
        }

        public void OnPostBtRefrescar()
        {
            try
            {
                var session = HttpContext.Session.GetString("Usuario");
                if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
                CargarListas();
                Lista = IFacturas!.Consultar();
                Actual = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtNuevo()
        {
            CargarListas();
            Actual = new Facturas();
            Lista = null;
        }

        public void OnPostBtModificar(int data)
        {
            try
            {
                CargarListas();
                OnPostBtRefrescar();
                Actual = Lista!.FirstOrDefault(x => x.Id == data);
                Lista = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtGuardar()
        {
            try
            {
                CargarListas();
                if (Actual == null) return;
                Actual = IFacturas!.Guardar(Actual!);
                if (Actual.Id == 0) return;
                OnPostBtRefrescar();
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; CargarListas(); }
        }

        public IActionResult OnPostBtPDF()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) return Redirect("/");

            CargarListas();
            Lista = IFacturas!.Consultar();

            using var ms = new MemoryStream();
            var doc = new Document(PageSize.A4, 30, 30, 40, 30);
            PdfWriter.GetInstance(doc, ms);
            doc.Open();

            var titulo = new Paragraph("Reporte de Facturas",
                new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD));
            titulo.Alignment = Element.ALIGN_CENTER;
            titulo.SpacingAfter = 15;
            doc.Add(titulo);

            doc.Add(new Paragraph($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm}",
                new Font(Font.FontFamily.HELVETICA, 9))
            { SpacingAfter = 10 });

            var tabla = new PdfPTable(5) { WidthPercentage = 100 };
            tabla.SetWidths(new float[] { 1, 2, 3, 2, 2 });

            BaseColor gris = new BaseColor(52, 58, 64);
            Font fEnc = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            foreach (var h in new[] { "ID", "Código", "Cliente", "Total", "Fecha" })
            {
                tabla.AddCell(new PdfPCell(new Phrase(h, fEnc))
                { BackgroundColor = gris, HorizontalAlignment = Element.ALIGN_CENTER, Padding = 6 });
            }

            Font fFila = new Font(Font.FontFamily.HELVETICA, 9);
            bool par = false;
            foreach (var e in Lista!)
            {
                BaseColor bg = par ? new BaseColor(240, 240, 240) : BaseColor.WHITE;
                var nombreCliente = ListaClientes?.FirstOrDefault(c => c.Id == e.Clientes)?.Nombre ?? "";
                foreach (var val in new[] { e.Id.ToString(), e.Codigo ?? "", nombreCliente, e.Total.ToString("N2"), e.Fecha.ToString("yyyy-MM-dd") })
                {
                    tabla.AddCell(new PdfPCell(new Phrase(val, fFila))
                    { BackgroundColor = bg, Padding = 5 });
                }
                par = !par;
            }

            doc.Add(tabla);
            doc.Close();

            return File(ms.ToArray(), "application/pdf", "Facturas.pdf");
        }

    }
}

