using iTextSharp.text;
using iTextSharp.text.pdf;
using Libreria_VR_Peliculas.Entidades;
using Libreria_VR_Peliculas_Presentacion.Implementaciones;
using Libreria_VR_Peliculas_Presentacion.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace APS_VR_Peliculas_Preseentacion.Pages
{
    public class RentasHTMLModel : PageModel
    {
        private IRentas_Presentacion? IRentas;
        private IClientes_Presentacion? IClientes;
        [BindProperty] public List<Rentas>? Lista { get; set; }
        [BindProperty] public Rentas? Actual { get; set; }
        [BindProperty] public bool Borrando { get; set; }
        public List<Clientes>? ListaClientes { get; set; }

        public RentasHTMLModel()
        {
            IRentas = new Rentas_Presentacion();
            IClientes = new Clientes_Presentacion();
        }

        private void CargarListas()
        {
            try { ListaClientes = IClientes!.Consultar(); }
            catch { ListaClientes = new List<Clientes>(); }
        }

        public void OnGet()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
            CargarListas();
            OnPostBtRefrescar();
        }

        public void OnPostBtRefrescar()
        {
            try
            {
                var session = HttpContext.Session.GetString("Usuario");
                if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
                CargarListas();
                Lista = IRentas!.Consultar();
                Actual = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtNuevo()
        {
            CargarListas();
            Actual = new Rentas();
            Lista = null;
        }

        public void OnPostBtModificar(int data)
        {
            try
            {
                CargarListas();
                OnPostBtRefrescar();
                Actual = Lista!.FirstOrDefault(x => x.Id == data);
                Lista = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtGuardar()
        {
            try
            {
                CargarListas();
                if (Actual == null) return;
                Actual = IRentas!.Guardar(Actual!);
                if (Actual.Id == 0) return;
                OnPostBtRefrescar();
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; CargarListas(); }
        }
        public IActionResult OnPostBtPDF()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) return Redirect("/");

            CargarListas();
            Lista = IRentas!.Consultar();

            using var ms = new MemoryStream();
            var doc = new Document(PageSize.A4, 30, 30, 40, 30);
            PdfWriter.GetInstance(doc, ms);
            doc.Open();

            var titulo = new Paragraph("Reporte de Rentas",
                new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD));
            titulo.Alignment = Element.ALIGN_CENTER;
            titulo.SpacingAfter = 15;
            doc.Add(titulo);

            doc.Add(new Paragraph($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm}",
                new Font(Font.FontFamily.HELVETICA, 9))
            { SpacingAfter = 10 });

            var tabla = new PdfPTable(6) { WidthPercentage = 100 };
            tabla.SetWidths(new float[] { 1, 3, 2, 1, 2, 2 });

            BaseColor gris = new BaseColor(52, 58, 64);
            Font fEnc = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            foreach (var h in new[] { "ID", "Cliente", "Precio Día", "Cantidad", "Fecha Renta", "Fecha Límite" })
            {
                tabla.AddCell(new PdfPCell(new Phrase(h, fEnc))
                { BackgroundColor = gris, HorizontalAlignment = Element.ALIGN_CENTER, Padding = 6 });
            }

            Font fFila = new Font(Font.FontFamily.HELVETICA, 9);
            bool par = false;
            foreach (var e in Lista!)
            {
                BaseColor bg = par ? new BaseColor(240, 240, 240) : BaseColor.WHITE;
                var nombreCliente = ListaClientes?.FirstOrDefault(c => c.Id == e.Clientes)?.Nombre ?? "";
                foreach (var val in new[] {
            e.Id.ToString(), nombreCliente, e.Precio_Dia.ToString("N2"),
            e.Cantidad.ToString(), e.Fecha_Renta.ToString("yyyy-MM-dd"), e.Fecha_Limite.ToString("yyyy-MM-dd") })
                {
                    tabla.AddCell(new PdfPCell(new Phrase(val, fFila))
                    { BackgroundColor = bg, Padding = 5 });
                }
                par = !par;
            }

            doc.Add(tabla);
            doc.Close();

            return File(ms.ToArray(), "application/pdf", "Rentas.pdf");
        }


    }
}
