using iTextSharp.text;
using iTextSharp.text.pdf;
using Libreria_VR_Peliculas.Entidades;
using Libreria_VR_Peliculas_Presentacion.Implementaciones;
using Libreria_VR_Peliculas_Presentacion.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace APS_VR_Peliculas_Preseentacion.Pages
{
    public class Rentas_PeliculasHTMLModel : PageModel
    {
        private IRentas_Peliculas_Presentacion? IRentas_Peliculas;
        private IRentas_Presentacion? IRentas;
        private IPeliculas_Presentacion? IPeliculas;
        [BindProperty] public List<Rentas_Peliculas>? Lista { get; set; }
        [BindProperty] public Rentas_Peliculas? Actual { get; set; }
        [BindProperty] public bool Borrando { get; set; }
        public List<Rentas>? ListaRentas { get; set; }
        public List<Peliculas>? ListaPeliculas { get; set; }

        public Rentas_PeliculasHTMLModel()
        {
            IRentas_Peliculas = new Rentas_Peliculas_Presentacion();
            IRentas = new Rentas_Presentacion();
            IPeliculas = new Peliculas_Presentacion();
        }

        private void CargarListas()
        {
            try { ListaRentas = IRentas!.Consultar(); } catch { ListaRentas = new List<Rentas>(); }
            try { ListaPeliculas = IPeliculas!.Consultar(); } catch { ListaPeliculas = new List<Peliculas>(); }
        }

        public void OnGet()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
            CargarListas();
            OnPostBtRefrescar();
        }

        public void OnPostBtRefrescar()
        {
            try
            {
                var session = HttpContext.Session.GetString("Usuario");
                if (string.IsNullOrEmpty(session)) { HttpContext.Response.Redirect("/"); return; }
                CargarListas();
                Lista = IRentas_Peliculas!.Consultar();
                Actual = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtNuevo()
        {
            CargarListas();
            Actual = new Rentas_Peliculas();
            Lista = null;
        }

        public void OnPostBtModificar(int data)
        {
            try
            {
                CargarListas();
                OnPostBtRefrescar();
                Actual = Lista!.FirstOrDefault(x => x.Id == data);
                Lista = null;
            }
            catch (Exception ex) { ViewData["Mensaje"] = ex.Message; }
        }

        public void OnPostBtGuardar()
        {
            try
            {
                CargarListas();
                if (Actual == null) return;

             
                Actual = IRentas_Peliculas!.Guardar(Actual!);

                if (Actual != null && Actual.Id != 0)
                {
                    

                    ViewData["Mensaje"] = "Registro guardado correctamente y vinculado.";
                    OnPostBtRefrescar();
                }
            }
            catch (Exception ex)
            {
                ViewData["Mensaje"] = "Error al guardar: " + ex.Message;
                CargarListas();
            }
        }

        public IActionResult OnPostBtPDF()
        {
            var session = HttpContext.Session.GetString("Usuario");
            if (string.IsNullOrEmpty(session)) return Redirect("/");

            CargarListas();
            Lista = IRentas_Peliculas!.Consultar();

            using var ms = new MemoryStream();
            var doc = new Document(PageSize.A4.Rotate(), 30, 30, 40, 30);
            PdfWriter.GetInstance(doc, ms);
            doc.Open();

            var titulo = new Paragraph("Reporte de Rentas Películas",
                new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD));
            titulo.Alignment = Element.ALIGN_CENTER;
            titulo.SpacingAfter = 15;
            doc.Add(titulo);

            doc.Add(new Paragraph($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm}",
                new Font(Font.FontFamily.HELVETICA, 9))
            { SpacingAfter = 10 });

            var tabla = new PdfPTable(7) { WidthPercentage = 100 };
            tabla.SetWidths(new float[] { 1, 2, 3, 1, 1, 2, 2 });

            BaseColor gris = new BaseColor(52, 58, 64);
            Font fEnc = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            foreach (var h in new[] { "ID", "Renta", "Película", "Cantidad", "Días", "Precio Día", "Subtotal" })
            {
                tabla.AddCell(new PdfPCell(new Phrase(h, fEnc))
                { BackgroundColor = gris, HorizontalAlignment = Element.ALIGN_CENTER, Padding = 6 });
            }

            Font fFila = new Font(Font.FontFamily.HELVETICA, 9);
            bool par = false;
            foreach (var e in Lista!)
            {
                BaseColor bg = par ? new BaseColor(240, 240, 240) : BaseColor.WHITE;
                var nombrePelicula = ListaPeliculas?.FirstOrDefault(p => p.Id == e.Peliculas)?.Nombre ?? "";
                foreach (var val in new[] {
            e.Id.ToString(), $"Renta #{e.Rentas}", nombrePelicula,
            e.Cantidad.ToString(), e.Dias.ToString(),
            e.Precio_Dia.ToString("N2"), e.Subtotal.ToString("N2") })
                {
                    tabla.AddCell(new PdfPCell(new Phrase(val, fFila))
                    { BackgroundColor = bg, Padding = 5 });
                }
                par = !par;
            }

            doc.Add(tabla);
            doc.Close();

            return File(ms.ToArray(), "application/pdf", "Rentas_Peliculas.pdf");
        }


    }
}
